<?php
    
    require_once "./Connect.php";

    session_start();
    $uid = $_SESSION["uid"];
    $date = $_GET["date"];
    
    if(empty($date)){
        $date = date("Y/m/d");
    }
    // Check if the user is already logged in, if yes then redirect him to welcome page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ./Login1.php");
    exit;
    }

    $exercise_name =  $reps = $sets = $weight = $weight_unit = $exercise_description= "";
    $exercise_name_error = $exercise_description_error = $date_error = $reps_error = $sets_error = $weight_error = $weight_unit_error = "";
    
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        $regex_date = "/(^[12]\d{3}\/(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])$)/";
        $regex = "\w*((%27)|('))((%6F)|o|(%4F))((%72)|r|(%52))/ix";
        //mysqli_prepare($link, $sql)
        if(empty(trim($_POST["exercise_name"])))
        {
            $exercise_name_error = "Please enter your exercise name.";
        } 
        else
        {
            $exercise_name = trim($_POST["exercise_name"]);

            if(!preg_match($regex,(trim($_POST["exercise_name"]))))
            {
                $exercise_name = trim($_POST["exercise_name"]);
            }
            else
            {
                $exercise_name_error = "Please re-enter your exercise name.";
            }

        }

        if(!empty(trim($_POST["exercise_description"]))){
            $exercise_description = trim($_POST["exercise_description"]);

            if(!preg_match($regex,(trim($_POST["exercise_description"]))))
            {
                $exercise_description = trim($_POST["exercise_description"]);
            }
            else
            {
                $exercise_description_error = "Please re-enter your description.";
            }
        } 
 
        if(!(empty(trim($_POST["date"]))))
        {
            if(preg_match($regex_date,(trim($_POST["date"]))))
            {
                $date = trim($_POST["date"]);
            }
            else
            {
                $date_error = "Date does not follow format yyyy/mm/dd.";
            }
        }
        else
        {
            $date = date("Y/m/d");
        }
 
        if(empty(trim($_POST["reps"])))
        {
            $reps_error = "Please enter reps completed.";
        } 
        else if (is_numeric(trim($_POST["reps"])))
        {
            $reps = trim($_POST["reps"]);
        } 
        else
        {
            $reps_error ="Reps can only be numbers.";
        }

        if(empty(trim($_POST["sets"])))
        {
            $sets_error = "Please enter sets completed.";
        } 
        else if (is_numeric(trim(($_POST["sets"]))))
        {
             $sets = trim($_POST["sets"]);
        } 
        else
        {
            $sets_error ="Sets can only be numbers.";
        }

        if(empty(trim($_POST["weight"])))
        {
            $weight_error = "Please enter amount of weights used.";
        } 
        else if (is_numeric(trim(($_POST["weight"]))))
        {
            $weight = trim($_POST["weight"]);
        } 
        else
        {
            $weight_error ="Weight can only be numbers.";
        }
        if (empty(trim($_POST["weight_unit"])))
        {
            $weight_unit_error ="Please enter the weight units used.";
        } 
        else
        {
             $weight_unit = trim($_POST["weight_unit"]);
        }

        //$ruid = 1;
        //$ruid = $_SESSION["uid"]

        //$sql = "INSERT INTO Users (ru_id,fname,lname,email_address,username,password) VALUES ('$ru_id','$fname','$lname','$email_address','$username','$encrypt_password')";
        if(empty($exercise_name_error) && empty($exercise_date_error) && empty($reps_error) && empty($sets_error) &&
		  empty($weight_error) && empty($weight_unit_error))
        {
            
        $sql = "INSERT INTO Workouts (uid, workout_date, exercise_name, reps, sets, weight, weight_units, description) VALUES ('$uid', '$date', '$exercise_name', '$reps', '$sets', '$weight', '$weight_unit', '$exercise_description')";
        
        if(mysqli_query($link, $sql))
        {
            header("location: ./Home.php");
        }else
        {
            echo "Something went wrong";
        }
        }
        mysqli_close($link);
          
    }

?>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>



<!DOCTYPE html>
<meta charset="UTF-8">

<!-- All NAVBar stuff below-->
<head>
    <meta charset="utf-8">
	<style type="text/css">
		@import url(https://fonts.googleapis.com/css?family=Raleway:300,400,600);


		body{
			margin: 0;
			font-size: .9rem;
			font-weight: 400;
			line-height: 1.6;
			color: #212529;
			text-align: left;
			background-color: #f5f8fa;
		}

		.navbar-register
		{
			box-shadow: 0 2px 4px rgba(0,0,0,.04);
		}

		.navbar-brand , .nav-link, .my-form
		{
			//font-family: Raleway, sans-serif;
		}

		.my-form
		{
			padding-top: 1.5rem;
			padding-bottom: 1.5rem;
		}

		.my-form .row
		{
			margin-left: 0;
			margin-right: 0;
		}

		.btn-primary
		{
			background-color: #c2011b !important;
			border-color: #c2011b !important;
		}
	</style>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">



    <link rel="icon" href="Favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>Add Exercise</title>

    <script src="js/modernizr.custom.95515.js"></script>
	<script>
		Modernizr.load([
			'https://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js',
			{
				test : Modernizr.input.list,
				nope : ['https://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css',
						'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js',
						'js/DatalistPolyfill.js']
			}
		]);
	</script>
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-light navbar-register">
    <div class="container">
        <a class="navbar-brand" href="./Home.php">
            <h1 style=font-size:30px><span style=color:rgb(200,16,46)>RU</span><span style=color:rgb(136,139,141)>Fit</span></h1>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="./Goals.php">My Goals</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="./Rewards.php">My Rewards</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="./Logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- All NAVBar stuff above-->

<main class="my-form">
    <div class="container">
        
        <div class="row justify-content-center">
            <div class="col-md-10">
                    <div class="card">
                        <div class="card-header">
                            <span class="pull-left">Add Exercise</span>
                            <!-- <span class="pull-right"> <?php echo $date ?> </span> -->
                        </div>
                        
                        <div class="card-body">

                          <!--<h1 align="center">&nbsp; Add a New Exercise</h1>-->
                          <form name="my-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                            <div class="form-group row">
                                <label for="exercise_name" class="col-md-4 col-form-label text-md-right">Exercise Name:</label>
                                <div class="col-md-6">
                                    <input list="exercise_name_list" class="form-control" name="exercise_name" required>
                                    <datalist id="exercise_name_list">
                                        <?php $sql = "SELECT DISTINCT Exercise_Name FROM Exercises ORDER BY Exercise_Name ASC";
                                            if($result = mysqli_query($link, $sql)){
                                                while ($row = mysqli_fetch_array($result, MYSQL_ASSOC)) {
                                                    echo "<option value=\"" . $row['Exercise_Name'] . "\">";
                                                }          
                                            }else{
                                                echo "Something went wrong. Please refresh the page.";
                                            }
                                            mysqli_close($link);
                                        ?>
                                    </datalist>
                                    <span class="help-block"><?php echo $exercise_name_error; ?></span>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="exercise_description" class="col-md-4 col-form-label text-md-right">Description:</label>
                                <div class="col-md-6">
                                    <textarea id="exercise_description" class="form-control" name="exercise_description" rows="3" maxlength="255"></textarea>
                                    <span class="help-block"><?php echo $exercise_description_error; ?></span>
                                </div>
                            </div>

                            <span>
                                <input type="hidden" name="date" id="date" value="<?php echo $date ?>" />                                  
                            </span>

                            <div class="form-group row">
                                <label for="reps" class="col-md-4 col-form-label text-md-right">Reps:</label>
                                <div class="col-md-6">
                                    <input type="number" class="form-control" name="reps" min="0" max="100" required/>
                                    <span class="help-block"><?php echo $reps_error; ?></span>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="sets" class="col-md-4 col-form-label text-md-right">Sets:</label>
                                <div class="col-md-6">
                                    <input type="number" class="form-control" name="sets" min="0" max="100" required/>
                                    <span class="help-block"><?php echo $sets_error; ?></span>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                <label for="weight" class="col-md-4 col-form-label text-md-right">Weight:</label>
                                <div class="col-md-4" style="padding-right:0px">
                                    <input type="number" class="form-control" name="weight" min="0" max="1000" required/>
                                    &nbsp;
                                    <span class="help-block"><?php echo $weight_error; ?></span>
                                    <br><br>
                                </div>
                                 <div class="col-md-2">
                                    <select id="weight_type_list" class="form-control" name="weight_unit">
                                        <option value="lbs">lbs</option>
                                        <option value="kg">kg</option>
                                    </select>
                                    <span class="help-block"><?php echo $weight_unit_error; ?></span>
                                </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <input type="submit" value="Add Exercise" class="btn btn-primary col-sm-6 text-sm-center offset-sm-3"/>
                            </div>

                          </form>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</main>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>


</body>
</html>
