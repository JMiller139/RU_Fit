<?php
  $dbhost = 'sql300.epizy.com';
  $username = 'epiz_23108305';
  $password = 'pxU0H40M1Q9JKR';
  $db = 'epiz_23108305_RUFit';

  $link = mysqli_connect($dbhost,$username,$password,$db) or die ("could not connect to mysql");
//  $link = new mysqli($dbhost, $username, $password, $db) or die ("could not connect to mysql");
?>