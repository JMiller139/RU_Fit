

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<html>

<!-- All NAVBar stuff below-->
<head>
    <meta charset="utf-8">
	<style type="text/css">
		@import url(https://fonts.googleapis.com/css?family=Raleway:300,400,600);


		body{
			margin: 0;
			font-size: .9rem;
			font-weight: 400;
			line-height: 1.6;
			color: #212529;
			text-align: left;
			background-color: #f5f8fa;
		}

		.navbar-register
		{
			box-shadow: 0 2px 4px rgba(0,0,0,.04);
		}

		.navbar-brand , .nav-link, .my-form, .login-form
		{
			//font-family: Raleway, sans-serif;
		}

		.my-form
		{
			padding-top: 1.5rem;
			padding-bottom: 1.5rem;
		}

		.my-form .row
		{
			margin-left: 0;
			margin-right: 0;
		}

		.login-form
		{
			padding-top: 1.5rem;
			padding-bottom: 1.5rem;
		}

		.login-form .row
		{
			margin-left: 0;
			margin-right: 0;
		}
		.btn-primary
		{
			background-color: #c2011b !important;
			border-color: #c2011b !important;
		}
	</style>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">



    <link rel="icon" href="Favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>Create Exercise</title>
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-light navbar-register">
    <div class="container">
    <a class="navbar-brand" href="./Login1.php">
        <h1 style=font-size:30px><span style=color:rgb(200,16,46)>RU</span><span style=color:rgb(136,139,141)>Fit</span></h1>
    </a>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="./Logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>

<!-- All NAVBar stuff above-->

<main class="my-form">
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-10">
                    <div class="card">
                        <div class="card-header">Create Exercise</div>
                        <div class="card-body">

                          <!--<h1 align="center">&nbsp; Add a New Exercise</h1>-->
                          <!--action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST"-->
                          <form name="my-form" >
                            <div class="form-group row">
                                <label for="exercise_name" class="col-md-4 col-form-label text-md-right">Exercise Name:</label>
                                <div class="col-md-6">
                                    <input type="text" name="exercise_name" id="exercise_name" class="form-control" /><br><br>
                                    <!--<span class="help-block"><?php echo $exercise_name_error; ?></span>-->
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="exercise_name" class="col-md-4 col-form-label text-md-right">Description:</label>
                                <div class="col-md-6">
                                    <textarea id="description" rows="6" cols="47" maxlength="250" class="form-control"> </textarea>
                                    <span class="help-block"><?php echo $date_error; ?></span> <br><br>
                                </div>
                            </div>

                            <div class="col-md-6 text-md-center offset-md-3">
                                <input type="submit" value="Create Exercise" class="btn btn-primary"/>
                            </div>

                          </form>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</main>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</body>
</html>
