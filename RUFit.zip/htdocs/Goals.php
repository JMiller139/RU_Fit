<?php

require_once "./Connect.php";
// Initialize the session
session_start();

$uid = $_SESSION["uid"];
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ./Login1.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>RU Fit Goals</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<style type="text/css">
		@import url(https://fonts.googleapis.com/css?family=Raleway:300,400,600);


        ul{
            margin: 0;
            padding: 0;
        }
        #goal-list *{
            float: left;
        }
        li, h3{
            clear: both;
            list-style: none;
        }
        input, button{
            ontline: none;
        }
       
        .btn-edit {
            border: none;
            padding: 0;
            background: none;
            margin-right: 15px;
        }
        .btn-delete {
            border: none;
            padding: 0;
            background: none;
            margin-left: 1px;
            margin-right: 1px;
            color: rgb(200,16,46);
        }
        h3{
            color: #333;
            font-weight: 700;
            font-size: 15px;
            border-bottom: 2px solid #333;
            padding: 30px 0 10px;
            margin: 0;
            text-transform: uppercase;
        }
        #goal-list {
            overflow: hidden;
            padding: 20px 0;
            border-bottom: 1px solid #eee;
        }
        li > label {
            font-size: 18px;
            line-height: 15px;
            width: 74%;
            padding: 0 0 0 11px;
        }
        label{
            font-size: 18px;
            line-height: 40px;
            width: 237px;
            padding: 11px;
        }
         .btn-complete {
            border: none;
            padding: 0;
            background: none;
            margin-left: 7px;
            margin-right: 10px;
        }
        .btn-incomplete {
            border: none;
            padding: 0;
            background: none;
            margin-left: 7px;
            margin-right: 10px;
        }
        #completed-tasks label {
            text-decoration: line-through;
            color: #888;
        }
       
		.navbar-register
		{
			box-shadow: 0 2px 4px rgba(0,0,0,.04);
		}

		.navbar-brand , .nav-link, .my-form, .login-form
		{
			//font-family: Raleway, sans-serif;
		}
	</style>


</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light navbar-register">
        <div class="container">
            <a class="navbar-brand" href="./Home.php">
             <h1 style=font-size:30px><span style=color:rgb(200,16,46)>RU</span><span style=color:rgb(136,139,141)>Fit</span></h1>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="./Goals.php">My Goals</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./Rewards.php">My Rewards</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./Logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
     <h3>Active Goals</h3>
      <ul id="incomplete-tasks">
        
      <?php $sql = "SELECT * FROM Goals Where uid='$uid' AND completed='0'";
            $exists = false;
           if($result = mysqli_query($link, $sql)){
               while ($row = mysqli_fetch_array($result, MYSQL_ASSOC)) {
                   $name = $row['goal_name'];
                   $id = $row['goal_id'];
                   ?>
                <li id="goal-list">
                    <form method "get" action="./CompleteGoal.php">
                        <button class = "btn-complete" type = "submit" name = "id" value = "<?php echo $id?>">
                            <i class="fa fa-square-o"></i>
                        </button>
                    </form>
                    <label><?php echo $name?></label>
                    <form method "get" action="./EditGoal.php">
                        <button class = "btn-edit" type = "submit" name = "id" value = "<?php echo $id?>">
                            <i class="fa fa-edit"></i>
                        </button>
                    </form>
                    <form method "get" action="./DeleteGoal.php">
                        <button class = "btn-delete" type = "submit" name = "id" value = "<?php echo $id?>">
                            <i class="fa fa-trash"></i>
                        </button>
                    </form>
                </li>               
                <?php
                    $exists = true;
               }
               if(!$exists){
                   echo "No goals set. Try creating some by clicking on the Create Goal button.";
               }
           }else{
               echo "Something went wrong. Please try again later!";
           }
       ?>
       
      </ul>
      <h3>Completed Goals</h3>
      <ul id="completed-tasks">
        <?php $sql = "SELECT * FROM Goals Where uid='$uid' AND completed='1'";
            $exists = false;
           if($result = mysqli_query($link, $sql)){
               while ($row = mysqli_fetch_array($result, MYSQL_ASSOC)) {
                   $name = $row['goal_name'];
                   $id = $row['goal_id'];
                   ?>
                <li id="goal-list">
                    <form method "get" action="./IncompleteGoal.php">
                        <button class = "btn-incomplete" type = "submit" name = "id" value = "<?php echo $id?>">
                            <i class="fa fa-check-square-o"></i>
                        </button>
                    </form>
                    <label><?php echo $name?></label>
                    <form method "get" action="./EditGoal.php">
                        <button class = "btn-edit" type = "submit" name = "id" value = "<?php echo $id?>">
                            <i class="fa fa-edit"></i>
                        </button>
                    </form>
                    <form method "get" action="./DeleteGoal.php">
                        <button class = "btn-delete" type = "submit" name = "id" value = "<?php echo $id?>">
                            <i class="fa fa-trash"></i>
                        </button>
                    </form>
                </li>                   
                <?php
                    $exists = true;
               }
               if(!$exists){
                   echo "No goals have been marked as complete yet.";
               }
           }else{
               echo "Something went wrong! Please refresh the page.";
           }
           mysqli_close($link);
       ?>
       
      </ul>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-4 offset-sm-4 col-centered">
                <a class="btn btn-default btn-lg btn-block" href="./CreateGoal.php" style=background-color:rgb(200,16,46);color:rgb(255,255,255)>Create Goal</a>
            </div>
        </div>
    </div>

</body>
</html>
