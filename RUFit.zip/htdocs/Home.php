<?php
// Home.php

require_once "./Connect.php";
// Initialize the session
session_start();
$uid = $_SESSION["uid"];
//echo $uid;
//$selected_date = $_SESSION["selected_date"];
//echo $selected_date;
// The date of the last completed workout
$completed_date = $_SESSION["completed_date"];
 
$query = "SELECT * FROM Workouts Where uid='$uid' And workout_date='" . date("Y-m-d") . "'"; 
$result = mysqli_query($link, $query);  

$is_complete_query = "SELECT Workouts.uid, Workouts.workout_date, Completed_Workouts.Comp_Workout_Date FROM Workouts LEFT JOIN Completed_Workouts ON Workouts.uid=Completed_Workouts.UID 
                        AND Workouts.workout_date=Completed_Workouts.Comp_Workout_Date WHERE Workouts.uid='$uid'";
$is_complete_result = mysqli_query($link, $is_complete_query);
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ./Login1.php");
    exit;
}
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>RU Fit Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
  

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/js/bootstrap-datepicker.min.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/css/bootstrap-datepicker3.css" rel="stylesheet" id="bootstrap-css">


<style type="text/css">
		@import url(https://fonts.googleapis.com/css?family=Raleway:300,400,600);

		.navbar-register
		{
			box-shadow: 0 2px 4px rgba(0,0,0,.04);
		}

		.navbar-brand , .nav-link, .my-form, .login-form
		{
			//font-family: Raleway, sans-serif;
		}

        .exercise-container
        {
            margin: 4px;
            padding: 5px;
        }

        .exercise-info
        {
            margin-left: 20px;
        }

        .description-info
        {
            margin-left: 20px;
            margin-right: 20px;
        }

        hr
        {
            margin-top: 5px;
            margin-bottom: 5px;
        }

        .btn-edit {
            border: none;
            padding: 0;
            background: none;
            margin-right: 3px;
        }
        .btn-delete {
            border: none;
            padding: 0;
            background: none;
            margin-left: 1px;
            margin-right: 1px;
            color: rgb(200,16,46);
        }


        #datepicker
        {
            width: 220px;
            font-size: 20px;
            margin-top: 20px;
            margin-bottom: 10px;
            margin-right: auto;
            margin-left: auto;
        }


	</style>


</head>
<body>
    <meta http-equiv="pragma" content="no-cache" />
    <meta http-equiv="expires" content="-1" />
    <nav class="navbar navbar-expand-lg navbar-light navbar-register">
        <div class="container">
            <a class="navbar-brand" href="#">
                <h1 style=font-size:30px><span style=color:rgb(200,16,46)>RU</span><span style=color:rgb(136,139,141)>Fit</span></h1>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="./Goals.php">My Goals</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./Rewards.php">My Rewards</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./Logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <div class="container">
        <div class="row">
            <div class="col-xs-3"></div>
            <div class='container col-xs-6'>
                <input type='text' class="form-control text-center col-xs-6" id='datepicker' value='<?php echo date("Y/m/d"); ?>' readonly />       
	        </div>
            <div class="col-xs-3"></div>
        </div>

        <div style=text-align:center>
            <button name="filter" id="filter" class="btn" style=background-color:rgb(200,16,46);color:rgb(255,255,255);margin-bottom:10px>Choose Date</button>
        </div>
    </div>

    <div id="output" class="container col-lg-5">
    <div id="order_table" >
        <?php 
            while($row = mysqli_fetch_array($result))  
            {
                $id = $row["workout_id"];
                //$completed_date = $row["workout_date"];
                
                ?>
                    <div class="exercise-container rounded border border-secondary" name="exercise_info">
                        <div class="font-weight-bold"> <?php echo $row["exercise_name"] ?> 
                            <span class="pull-right">
                                <div class="d-inline-block">
                                    <form method="get" action="./EditExercise.php">
                                        <button class="btn-edit" type="submit" name="id" value="<?php echo $id?>">
                                            <i class="fa fa-edit"></i>
                                        </button>  
                                    </form>
                                </div>
                                <div class="d-inline-block">
                                    <form method="get" action="./DeleteExercise.php">
                                        <button class="btn-delete" type="submit" name="id" value="<?php echo $id?>">
                                            <i class="fa fa-trash"></i>
                                        </button>  
                                    </form>
                                </div>
                            </span>                            
                        </div>
                        <div>
                            <span class="exercise-info">Sets: <?php echo $row["sets"]?></span>
                            <span class="exercise-info">Reps: <?php echo $row["reps"]?></span>
                            <span class="exercise-info">Weight: <?php echo $row["weight"] . " " . $row["weight_units"]?></span>
                       </div>
                        <?php
                        if(!empty($row["description"])){
                        ?>
                            <hr>
                            <div class="description-info">Description: <?php echo $row["description"] ?></div>
                        <?php
                        }
                        ?>
                    </div>
             <?php         
            }  
        ?>  
    
    

    </div>

    <?php 
            //echo "<br />**** <br />" . $selected_date . "<br /> ****<br />";
            //echo $_SESSION["initial_load"];
            //$isTodayComplete = 0;
            $isTodayComplete = 0;
            $isSelectedComplete = 0;
            //echo date("Y-m-d");
            while($row = mysqli_fetch_array($is_complete_result))  
            {
                if ($row["Comp_Workout_Date"] == date("Y-m-d"))
                {
                    $isTodayComplete = 1;
                }
                
                if ($selected_date = $row["Comp_Workout_Date"])
                {
                    $isSelectedComplete = 1;
                }
                
               // echo $row["uid"] . " ";
               // echo $row["workout_date"] . " ";
               // echo $row["Comp_Workout_Date"] . " " . $isTodayComplete;
               // echo "<br />";

                
            }
            //echo $isTodayComplete;
            //echo $isSelectedComplete;
        ?>

    <div id="buttons">
    <?php 
        if ($isSelectedComplete == 0 && mysqli_num_rows($result) > 0) 
        {
    ?>    
        <div class="container">
            <div class="row">
                <div class="col-sm-4 offset-sm-4 col-centered offset-xs-5 col-xs-2">
                    <a class="btn btn-default btn-lg btn-block" id="AddExercise" style=background-color:rgb(200,16,46);color:rgb(255,255,255);margin-top:10px;margin-bottom:10px>Add Exercise</a>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4 offset-sm-4 col-centered offset-xs-5 col-xs-2">
                    <!--<button class="btn btn-default btn-lg btn-block" id="CompleteWorkout"  
                        style="background-color:rgb(200,16,46);color:rgb(255,255,255);margin-bottom:10px">Complete Workout</button>  -->
                    <form method="get" action="./UpdateRewardProgress.php">
                        <input type = "hidden" name = "id" value = "<?php echo $id?>">
                        <input type = "hidden" name = "completed_date" value = "<?php echo $completed_date?>">
                        <input type="submit" value="Complete Workout" class="btn btn-default btn-lg btn-block" id="CompleteWorkout"
                            style="background-color:rgb(200,16,46);color:rgb(255,255,255);margin-top:5px;margin-bottom:5px">
                    </form>               
                </div>
            </div>
        </div>
    <?php 
        }
        else
        {       
    ?>
            <div class="container">
                <div class="row">
                    <div class="col-sm-4 offset-sm-4 col-centered offset-xs-5 col-xs-2">
                        <a class="btn btn-default btn-lg btn-block" id="AddExercise" style="background-color:rgb(200,16,46);color:rgb(255,255,255);margin-top:10px;margin-bottom:10px;">Add Exercise</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4 offset-sm-4 col-centered offset-xs-5 col-xs-2">
                        <!--<button class="btn btn-default btn-lg btn-block" id="CompleteWorkout"  
                            style="background-color:rgb(200,16,46);color:rgb(255,255,255);margin-bottom:10px">Complete Workout</button>  -->
                        <form method="get" action="./UpdateRewardProgress.php">
                            <input type = "hidden" name = "id" value = "<?php echo $id?>">
                            <input type = "hidden" name = "completed_date" value = "<?php echo $completed_date?>">
                            <input type="submit" value="Complete Workout" class="btn btn-default btn-lg btn-block" id="CompleteWorkout"
                                style="background-color:rgb(200,16,46);color:rgb(255,255,255);margin-top:5px;margin-bottom:5px" disabled>
                        </form>               
                    </div>
                </div>
            </div>
    <?php
        }
    ?>
    </div>
    </div>

    <script>

         //document.getElementById('datepicker').innerHTML = 'your tip has been submitted!';
        var from_date = "";
         $(document).ready(function(){  
            $(function () {

	            $('#datepicker').datepicker({
	                format: "yyyy/mm/dd",
	                autoclose: true,
	                todayHighlight: true,
		            showOtherMonths: true,
		            selectOtherMonths: true,
		            autoclose: true,
		            changeMonth: true,
		            changeYear: true,
		            orientation: "button"
                });
	        });
            $('#filter').click(function(){  
                from_date = $('#datepicker').val();  
                  
                if(from_date != '')  
                {  
                    $.ajax({  
                        url:"filter2.php",  
                        method:"POST",  
                            
                        data:{from_date:from_date},
                        success:function(data)  
                        {
                            //$('#order_table').html(data);
                            //$('#buttons').html();
                            $('#output').html(data);
                        }  
                    });
                }  
                else  
                {  
                     alert("Please Select Date");  
                }
           });  
          
      });  
        $(document).on('click', '#AddExercise', function(){ 
            window.open('./AddExercise.php?date='+from_date,"_self");
        });
 

         
        n =  new Date();
        y = n.getFullYear();
        m = n.getMonth() + 1;
        d = n.getDate();
        document.getElementById("date").innerHTML = m + "/" + d + "/" + y;

	</script>


</body>
</html>
