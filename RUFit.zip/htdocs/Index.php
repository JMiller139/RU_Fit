<html>

<body>





<?php

$Exercise_Name = $_POST['Exercise_Name'];
$reps = $_POST['reps'];
$sets = $_POST['sets'];
$weight = $_POST['weight'];
//$date = date("Y/m/d");

$date = $_POST['date'];

if ($date == "")
{
    $date = date("Y/m/d");
}

$ruid = 1;

$exerciseID = 1;


$con = mysql_connect("sql300.epizy.com","epiz_23108305","pxU0H40M1Q9JKR");

if (!$con)

  {

  die('Could not connect: ' . mysql_error());

  }



mysql_select_db("epiz_23108305_RUFit", $con);



$sql="INSERT INTO Workouts (RU_ID, Workout_Date, Exercise_Name, Reps, Sets, Weight)

VALUES


('$ruid', '$date', '$Exercise_Name', '$reps', '$sets', '$weight')";



if (!mysql_query($sql,$con))

  {

  die('Error: ' . mysql_error());

  }

echo "1 record added";



mysql_close($con)

?>

</body>

</html>
