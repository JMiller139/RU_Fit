<?php

require_once "./Connect.php";
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: ./Home.php");
    exit;
}
 
 
// Define variables and initialize with empty values
$username = $password = "";
$login_error = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT uid, username, password FROM Users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $uid, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["uid"] = $uid;
                            $_SESSION["username"] = $username;   
                            $_SESSION["initial_load"] = 0;                                                  
                            
                            // Redirect user to welcome page
                            header("location: ./Home.php");
                        } else{
                            // Display an error message if password is not valid
                            $login_error = "Your username or password was incorrect";
                        }
                    }
                } else{
                    // Display an error message if username doesn't exist
                    $login_error = "Your username or password was incorrect";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>

<html lang="en">
<head>
  <title>RU Fit Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>


  <div class="container text-center" style=padding-top:20px>
    <h1 style=font-size:50px><span style=color:rgb(200,16,46)>RU</span><span style=color:rgb(136,139,141)>Fit</span></h1>
  </div>

  <form name="my-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    <div class="container">
        <div class="col-sm-4 col-centered">
        </div>
        <div class="col-sm-4 col-centered">
            <div class="form-group">
                <p><br></p>
                <label for="username">Username:</label>
                <input type="text" class="form-control" name="username">
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" class="form-control" name="password">
                <p><br></p>
                <span class="help-block"><?php echo $login_error; ?></span>
            </div>
            <input class="btn btn-default btn-lg btn-block" type="submit" style=background-color:rgb(200,16,46);color:rgb(255,255,255) value="Login">
            <hr class="my-4" style=width:80%>
            <a class="btn btn-default btn-lg btn-block" href="./Register.php" style=background-color:rgb(136,139,141);color:rgb(255,255,255) role="button">Register</a>
        </div>
        <div class="col-sm-4 col-centered">
        </div>
    </div>
  </form>


</body>
</html>
