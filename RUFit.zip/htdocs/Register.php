<?php
	require_once "./Connect.php";
	
	$username = $password = $fname = $lname = $ru_id = $email_address = $password_confirm = "";
	$username_error = $password_error = $fname_error = $lname_error = $ru_id_error = $email_address_error =
    $password_confirm_error = "";  
	
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		if(empty(trim($_POST["username"]))){
			$username_error = "Please enter your RU username.";
		}else{
			$sql = "SELECT uid FROM Users WHERE username = ?";
			if($stmt = mysqli_prepare($link, $sql)){

				mysqli_stmt_bind_param($stmt, "s", $param_username);

				$param_username = trim($_POST["username"]);

				if(mysqli_stmt_execute($stmt)){
					mysqli_stmt_store_result($stmt);

					if(mysqli_stmt_num_rows($stmt) == 1){
						$username_error = "An account with this username has already been created!";
					} else{
						$username = trim($_POST["username"]);
					}
				} else{
					echo "Oops! Something went wrong. Please try again later.";
				}
			}
			mysqli_stmt_close($stmt);
		}
		if(empty(trim($_POST["first-name"]))){
			$fname_error = "Please enter your first name.";
		} elseif(strlen(trim($_POST["first-name"])) > 25){
			$fname_error = "First name cannot exceed 25 characters.";
		} else{
			$fname = trim($_POST["first-name"]);
		}
		
		if(empty(trim($_POST["last-name"]))){
			$lname_error = "Please enter your last name.";
		} elseif(strlen(trim($_POST["last-name"])) > 25){
			$lname_error = "Last name cannot exceed 25 characters.";
		} else{
			$lname = trim($_POST["last-name"]);
		}
		
		if(empty(trim($_POST["ru-id"]))){
			$ru_id_error = "Please enter your RU id.";
		} elseif(strlen(trim($_POST["ru-id"])) != 9){
			$ru_id_error = "Invalid RU id. Your RU id is exactly 9 digits long.";
		} else{
			$ru_id = trim($_POST["ru-id"]);
		}
		
		if(empty(trim($_POST["email-address"]))){
			$email_address_error = "Please enter your RU email address.";
		} elseif(strlen(trim($_POST["email-address"])) > 35){
			$email_address_error = "Email too long, Please try again.";
		} else{
			$email_address = trim($_POST["email-address"]);
		}
		
		if(empty(trim($_POST["password-first"]))){
			$password_error = "Please enter your password.";
		} elseif(strlen(trim($_POST["password-first"])) < 6){
			$password_error = "Password must have atleast 6 characters.";
		} else{
			$password = trim($_POST["password-first"]);
		}
		
		if(empty(trim($_POST["password-confirm"]))){
			$password_confirm_error = "Please confirm password.";
		} else{
			$password_confirm = trim($_POST["password-confirm"]);
			if(empty($password_error) && ($password != $password_confirm)){
				$password_confirm_error = "Password did not match.";
			}
		}
		if(empty($username_error) && empty($password_error) && empty($password_confirm_error) && empty($fname_error) &&
		empty($ru_id_error) && empty($email_address_error) && empty($lname_error)){
            $encrypt_password = password_hash($password, PASSWORD_DEFAULT);

			$sql = "INSERT INTO Users (ru_id,fname,lname,email_address,username,password) VALUES ('$ru_id','$fname','$lname','$email_address','$username','$encrypt_password')";
				if(mysqli_query($link, $sql)){
					header("location: ./Login1.php");
				}else{
					echo "Something went wrong. Please try again.";
				}
			}
		mysqli_close($link);
	}
	
?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<style type="text/css">
		@import url(https://fonts.googleapis.com/css?family=Raleway:300,400,600);


		body{
			margin: 0;
			font-size: .9rem;
			font-weight: 400;
			line-height: 1.6;
			color: #212529;
			text-align: left;
			background-color: #f5f8fa;
		}

		.navbar-register
		{
			box-shadow: 0 2px 4px rgba(0,0,0,.04);
		}

		.navbar-brand , .nav-link, .my-form, .login-form
		{
			//font-family: Raleway, sans-serif;
		}

		.my-form
		{
			padding-top: 1.5rem;
			padding-bottom: 1.5rem;
		}

		.my-form .row
		{
			margin-left: 0;
			margin-right: 0;
		}

		.login-form
		{
			padding-top: 1.5rem;
			padding-bottom: 1.5rem;
		}

		.login-form .row
		{
			margin-left: 0;
			margin-right: 0;
		}
		.btn-primary
		{
			background-color: #c2011b !important;
			border-color: #c2011b !important;
		}
	</style>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">



    <link rel="icon" href="Favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>Register</title>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light navbar-register">
    <div class="container">
    <a class="navbar-brand" href="./Login1.php">
        <h1 style=font-size:30px><span style=color:rgb(200,16,46)>RU</span><span style=color:rgb(136,139,141)>Fit</span></h1>
    </a>
</nav>

<main class="my-form">
    <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">Register</div>
                        <div class="card-body">
                            <form name="my-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                                <div class="form-group row">
                                    <label for="first_name" class="col-md-4 col-form-label text-md-right">First Name</label>
                                    <div class="col-md-6">
                                        <input type="text" id="first_name" class="form-control" name="first-name">
                                        <span class="help-block"><?php echo $fname_error; ?></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="email_address" class="col-md-4 col-form-label text-md-right">Last Name</label>
                                    <div class="col-md-6">
                                        <input type="text" id="last_name" class="form-control" name="last-name">
                                        <span class="help-block"><?php echo $lname_error; ?></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="user_name" class="col-md-4 col-form-label text-md-right">User Name</label>
                                    <div class="col-md-6">
                                        <input type="text" id="user_name" class="form-control" name="username">
                                        <span class="help-block"><?php echo $username_error; ?></span>
                                    </div>
                                </div>
								
								<div class="form-group row">
                                    <label for="ru_id" class="col-md-4 col-form-label text-md-right">RU ID</label>
                                    <div class="col-md-6">
                                        <input type="text" id="ru_id" class="form-control" name="ru-id">
                                        <span class="help-block"><?php echo $ru_id_error; ?></span>
                                    </div>
                                </div>
								
                                <div class="form-group row">
                                    <label for="email_address" class="col-md-4 col-form-label text-md-right">E-Mail Address</label>
                                    <div class="col-md-6">
                                        <input type="text" id="email_address" class="form-control" name="email-address">
                                        <span class="help-block"><?php echo $email_address_error; ?></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="password_first" class="col-md-4 col-form-label text-md-right">Password</label>
                                    <div class="col-md-6">
                                        <input type="password" id="password_first" class="form-control" name="password-first">
                                        <span class="help-block"><?php echo $password_error; ?></span>
                                    </div>
                                </div>
								
								<div class="form-group row">
                                    <label for="password_confirm" class="col-md-4 col-form-label text-md-right">Confirm Password</label>
                                    <div class="col-md-6">
                                        <input type="password" id="password_confirm" class="form-control" name="password-confirm">
                                        <span class="help-block"><?php echo $password_confirm_error; ?></span>
                                    </div>
                                </div>

                                    <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-primary">
                                        Register
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
            </div>
        </div>
    </div>

</main>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</body>
</html>
