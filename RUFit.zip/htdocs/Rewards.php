<?php
//Rewards.php

require_once "./Connect.php";
// Initialize the session
session_start();
$uid = $_SESSION["uid"];

$query = "SELECT * FROM Users Where uid='$uid'";  
$result = mysqli_query($link, $query); 
 
$rewards_query = "SELECT * FROM Rewards WHERE RID NOT IN (SELECT RID FROM Claimed WHERE uid='$uid') ORDER BY Required_Points";
$rewards_result = mysqli_query($link, $rewards_query);

$rewards_query2 = "SELECT * FROM Rewards WHERE RID NOT IN (SELECT RID FROM Claimed WHERE uid='$uid') ORDER BY Required_Points";
$rewards_result2 = mysqli_query($link, $rewards_query2);

$completed_query = "SELECT * FROM Rewards INNER JOIN Claimed ON Rewards.RID = Claimed.RID Where UID='$uid' ORDER BY Required_Points";
$completed_result = mysqli_query($link, $completed_query);

$max_query = "SELECT MAX(Required_Points) AS max_reward FROM Rewards";
$max_reward = mysqli_query($link, $max_query);


// Check if the user is already logged in, if yes then redirect him to welcome page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ./Login1.php");
    exit;
}
 
?>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<!--<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<!DOCTYPE html>
<meta charset="UTF-8">

<!-- All NAVBar stuff below-->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" type="text/css" href="loading-bar.css"/>
    <script type="text/javascript" src="loading-bar.js"></script> 

    <style type="text/css">
		@import url(https://fonts.googleapis.com/css?family=Raleway:300,400,600);


		body{
			margin: 0;
			font-size: .9rem;
			font-weight: 400;
			line-height: 1.6;
			color: #212529;
			text-align: left;
			background-color: #f5f8fa;
		}

		.navbar-register
		{
			box-shadow: 0 2px 4px rgba(0,0,0,.04);
		}

		.navbar-brand , .nav-link, .my-form
		{
			//font-family: Raleway, sans-serif;
		}

		.my-form
		{
			padding-top: 1.5rem;
			padding-bottom: 1.5rem;
		}

		.my-form .row
		{
			margin-left: 0;
			margin-right: 0;
		}

		.btn-primary
		{
			background-color: #c2011b !important;
			border-color: #c2011b !important;
		}

         .ldBar{position:relative;}
         .ldBar.label-center > .ldBar-label{position:absolute;top:55%;left:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);text-shadow:0 0 3px #fff;font-weight:bold}
        
        .ldBar-label:after {content:" Points"; display:inline}
        
        .ldBar.no-percent .ldBar-label:after{content:""}

        .exercise-container
        {
            margin: 4px;
            padding: 5px;
        }

        .exercise-info
        {
            margin-left: 20px;
        }

        .description-info
        {
            margin-left: 20px;
        }

        hr
        {
            margin-top: 5px;
            margin-bottom: 5px;
        }

	</style>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">
    <link rel="icon" href="Favicon.png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

</head>

<body>

    <!--<link rel="stylesheet" type="text/css" href="loading-bar.css"/>-->
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->

    <nav class="navbar navbar-expand-lg navbar-light navbar-register">
        <div class="container">
            <a class="navbar-brand" href="./Home.php">
                <h1 style=font-size:30px><span style=color:rgb(200,16,46)>RU</span><span style=color:rgb(136,139,141)>Fit</span></h1>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="./Goals.php">My Goals</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./Rewards.php">My Rewards</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./Logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <script type="text/javascript" src="loading-bar.js"></script>

   <!-- Get Reward Progress from Users Table -->
    <?php  
        while($row = mysqli_fetch_array($result)) {                   
            $reward_progress = $row["reward_progress"];   
        }

        $current_goal = 0;
        $current_starting_point = 0;
        $goal_message = "";
    ?>       

    <?php 
        while ($row = mysqli_fetch_array($max_reward)) {
            $next_goal = $row["max_reward"]; 
            $max_reward_number = $row["max_reward"];
        }

        $goal_message2 = "";
        $equal = false;
        $equal_max = false;
        $earned_goal = 0;
        $current = 0;
        while($row = mysqli_fetch_array($rewards_result2)) {
            // If Your Current Point total is above the max reward point amount
            if ($reward_progress > $max_reward_number) {
                $goal_message = "No New Rewards Exist";
                break;
            }
            // If your current point total is equal to a reward point amount
            else if ($reward_progress == $row["Required_Points"]) {
                $earned_goal = $row["Required_Points"];
                
                // if you current point total is equal to the max reward point amount
                if ($reward_progress == $max_reward_number)
                {
                    $goal_message2 = $earned_goal . " Point Reward Earned!";
                    $equal_max = true;
                }
                // if your current point total is equal to a non-max reward point amount
                else {
                    $goal_message2 = $earned_goal . " Point Reward Earned! <br /> Next Reward: ";
                    $equal = true;
                }  
            }
            else if ($next_goal >= $row["Required_Points"] && $reward_progress < $row["Required_Points"]) {
                $next_goal = $row["Required_Points"];
                $goal_message = ($next_goal - $reward_progress) . " Points Until Next Reward";
            }

            // If Current Point Total is Equal to a non-max Reward Point Amount
            if ($equal == true) {
                $goal_message = $goal_message2 . $next_goal . " Points";
            }

            // If Current Point Total is Equal to the Max Reward Point Amount
            if ($equal_max == true) {
                $goal_message = $goal_message2 . "<br /> Congrats! All Rewards Earned!";
            }

        
        }
        
        if ($reward_progress > $next_goal) {
                $data_max = $reward_progress;
        }
        else {
            $data_max = $next_goal;
        }
    ?>


    <div class="container">
        <div id="myItem1" data-preset="fan" style="width:70%;height:30%;margin:auto" class="ldBar label-center" data-stroke="rgb(200,16,46)" 
            data-value='<?php echo $reward_progress ?>' data-min="0" data-max='<?php echo $data_max ?>' ></div>

        <p id="goal_message2" class="col-sm-12 text-center" style="font-weight:bold"></p>
        <script>
        var current = <?php echo $reward_progress ?>;
        var message = "<?php echo $goal_message ?>";
        
        var goal = 200;
        var distance = (current / goal) * 100;
        var bar1 = new ldBar("#myItem1");
        var bar2 = document.getElementById('myItem1').ldBar;     
        document.getElementById("goal_message2").innerHTML = message;  
        </script>
    </div>

    <hr />

    <?php
    $exists = false;
    while($row = mysqli_fetch_array($rewards_result)) {
        $reward_name = $row["Reward_Name"];
        $required_points = $row["Required_Points"];
        $id = $row["RID"];

        if ($reward_progress >= $required_points) {
    ?>
        <div id="order_table" class="container col-lg-5">
            <div id="100Point" class="exercise-container rounded border border-secondary text-center" name="exercise_info">
                <div class="font-weight-bold"> <?php echo $row["Required_Points"] ?> Point Reward</div>  
                <div>
                <span class="exercise_info col-sm-12"><?php echo $row["Reward_Name"] ?></span> 
                </div>  
                <hr />           
                <form method="get" action="./CompleteReward.php">
                    <input type = "hidden" name = "id" value = "<?php echo $id?>">
                    <input type="submit" value="Claim Reward" class="btn btn-default btn-sm" id="ClaimReward" style="background-color:rgb(200,16,46);color:rgb(255,255,255);margin-top:5px;margin-bottom:5px">
                </form>
            </div>
        </div>

    <?php
        }
        else {
    ?>
            <div id="order_table" class="container col-lg-5">
            <div id="100Point" class="exercise-container rounded border border-secondary text-center" name="exercise_info" style="background-color:LightGray;">
                <div class="font-weight-bold"> <?php echo $row["Required_Points"] ?> Point Reward</div>  
                <div>
                <span class="exercise_info col-sm-12"><?php echo $row["Reward_Name"] ?></span> 
                </div>  
                <hr /> 
                <form method="get" action="./CompleteReward.php">
                    <input type = "hidden" name = "id" value = "<?php echo $id?>">
                    <input type="submit" value="Claim Reward" class="btn btn-default btn-sm" id="ClaimReward" style="background-color:rgb(200,16,46);color:rgb(255,255,255);margin-top:5px;margin-bottom:5px" disabled>
                </form>
            </div>
        </div>
    <?php     
        }
        $exists = true;
    }
    if(!$exists){
    ?>
        <div class="font-weight-bold text-center">No Rewards Left To Earn</div> <br />
    <?php
    }
    ?>

    <hr />
    <div class="font-weight-bold text-center" style="text-decoration:underline; font-size:1em">Claimed Rewards</div> <br />

    <?php
    $exists = false;
    while($row = mysqli_fetch_array($completed_result)) {
        $reward_name = $row["Reward_Name"];
        $required_points = $row["Required_Points"];
        $id = $row["RID"];
    ?>
            <div id="order_table" class="container col-lg-5">
                <div id="100Point" class="exercise-container rounded border border-secondary text-center" name="exercise_info" style="background-color:LightGray;">
                    <div class="font-weight-bold"> <?php echo $row["Required_Points"] ?> Point Reward</div>  
                    <div>
                    <span class="exercise_info col-sm-12"><?php echo $row["Reward_Name"] ?></span> 
                    </div>  
                    <hr />              
                </div>
            </div>
    <?php
        $exists = true;
    }
    if(!$exists){
    ?>
        <div class="font-weight-bold text-center">No Rewards Have Been Claimed</div> <br />
    <?php
    }
    ?>

    <br /> <br />
</body>
</html>