<?php
    
    require_once "./Connect.php";

    session_start();
    $uid = $_SESSION["uid"];
    $goal_id = $_GET["id"];
    // Check if the user is already logged in, if yes then redirect him to welcome page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ./Login1.php");
    exit;
    }
    $sql = "UPDATE Goals SET completed = 0 WHERE uid = '$uid' AND goal_id = '$goal_id'";
    if(mysqli_query($link, $sql))
    {
        header("location: ./Goals.php");
    }else{
        echo "Something went wrong! Please refresh the page.";
    }
    

    ?>