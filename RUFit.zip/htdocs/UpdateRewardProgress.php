<?php
    
    require_once "./Connect.php";

    session_start();
    $uid = $_SESSION["uid"];
    //$goal_id = $_GET["id"];
    $RID = $_GET["id"];
    //$completed_date = $_GET["completed_date"];
    $completed_date = $_SESSION["completed_date"];
    echo $completed_date;
    //$_SESSION["completed_date"] = $completed_date;
    //$completed_date = date("Y-m-d");

    // Check if the user is already logged in, if yes then redirect him to welcome page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ./Login1.php");
    exit;
    }

    if ($_SESSION["initial_load"] == 0)
    {
        $completed_date = date("Y-m-d");
    }
    else
    {
        $completed_date = $_SESSION["completed_date"];
    }
    
    $sql = "Update Users SET reward_progress=reward_progress+10 WHERE uid='$uid'";
    //$update_progress_result = mysqli_query($link, $update_progress_query);

    $complete_workout = "INSERT INTO Completed_Workouts (UID, Comp_Workout_Date) VALUES ('$uid', '$completed_date')";
    
    if(mysqli_query($link, $sql))
    {
        header("location: ./Home.php");
    }else{
        echo "Something went wrong! Please refresh the page.";
    }
    
    if(mysqli_query($link, $complete_workout))
    {
        header("location: ./Home.php");
    }else{
        echo "Something went wrong! Please refresh the page.";
    }
    
    ?>