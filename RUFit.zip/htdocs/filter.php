<?php  
 //filter.php  
//$uid = 4;

session_start();
$uid = $_SESSION["uid"];

// Check if the user is already logged in, if yes then redirect him to welcome page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
header("location: ./Login1.php");
exit;
}

 //if(isset($_POST["from_date"], $_POST["to_date"]))  
 if(isset($_POST["from_date"]))
 {  
      $connect = mysqli_connect("sql300.epizy.com", "epiz_23108305", "pxU0H40M1Q9JKR", "epiz_23108305_RUFit"); 
      $output = '';  
     /* $query = "  
           SELECT * FROM Workouts  
           WHERE workout_date BETWEEN '".$_POST["from_date"]."' AND '".$_POST["to_date"]."'  
      ";  */
      $query = "SELECT * FROM Workouts WHERE uid='$uid' AND workout_date='".$_POST["from_date"]."' ";
      $result = mysqli_query($connect, $query);  
      $output .= '  
           <table class="table table-bordered">  
                <tr>  
                     <th width="5%">ID</th>  
                     <th width="30%">Customer Name</th>  
                     <th width="43%">Item</th>  
                     <th width="10%">Value</th>  
                       
                </tr>  
      ';  
      if(mysqli_num_rows($result) > 0)  
      {  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '  
                     <tr>  
                          <td>'. $row["exercise_name"] .'</td>  
                          <td>'. $row["reps"] .'</td> 
                          <td>'. $row["sets"] .'</td> 
                          <td>'. $row["weight"] .'</td>
                     </tr>  
                ';  
           }  
           
      }  
      else  
      {  
           $output .= '  
                <tr>  
                     <td colspan="5">No Order Found</td>  
                </tr>  
           ';  
      }  
      $output .= '</table>';  
      echo $output;  
 }  
 ?>