

<?php  
 //filter2.php  

require_once "./Connect.php";
session_start();
$uid = $_SESSION["uid"];

$_SESSION["initial_load"] = 1;

// Check if the user is already logged in, if yes then redirect him to welcome page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
header("location: ./Login1.php");
exit;
}
 
 if(isset($_POST["from_date"]))
 {  
      $_SESSION["completed_date"] = $_POST["from_date"];
      $_SESSION["selected_date"] = $_POST["from_date"];
      $selected_date = date("Y-m-d", strtotime($_SESSION["completed_date"]));
      $completed_date = $_SESSION["completed_date"]; 
      $output = '';  
      $query = "SELECT * FROM Workouts WHERE uid='$uid' AND workout_date='".$_POST["from_date"]."' ";
      $result = mysqli_query($link, $query);   

    $is_complete_query = "SELECT Workouts.uid, Workouts.workout_date, Completed_Workouts.Comp_Workout_Date FROM Workouts LEFT JOIN Completed_Workouts ON Workouts.uid=Completed_Workouts.UID 
                    AND Workouts.workout_date=Completed_Workouts.Comp_Workout_Date WHERE Workouts.uid='$uid'";
    $is_complete_result = mysqli_query($link, $is_complete_query);

      if(mysqli_num_rows($result) > 0)  
      {  
           while($row = mysqli_fetch_array($result))  
           {  
               
                $id = $row["workout_id"];
                $output .=
                    "<div class=\"exercise-container rounded border border-secondary\" name=\"exercise_info\">".
                        "<div class=\"font-weight-bold\">" . $row["exercise_name"] .
                        "    <span class=\"pull-right\">
                                <div class=\"d-inline-block\">
                                    <form method=\"get\" action=\"./EditExercise.php\">
                                        <button class=\"btn-edit\" type=\"submit\" name=\"id\" value=".$id.">
                                            <i class=\"fa fa-edit\"></i>
                                        </button>  
                                    </form>
                                </div>
                                <div class=\"d-inline-block\">
                                    <form method=\"get\" action=\"./DeleteExercise.php\">
                                        <button class=\"btn-delete\" type=\"submit\" name=\"id\" value=".$id.">
                                            <i class=\"fa fa-trash\"></i>
                                        </button>  
                                    </form>
                                </div>
                            </span>".                        
                        "</div>".
                        "<div>" .
                            "<span class=\"exercise-info\">Sets: "   . $row["sets"]. "</span>" .
                            "<span class=\"exercise-info\">Reps: "   . $row["reps"]. "</span>" .
                            "<span class=\"exercise-info\">Weight: " . $row["weight"]. " " . $row["weight_units"] . "</span>" .
                        "</div>";

                        if(!empty($row["description"])){
                            $output .= "<hr>";
                            $output .= "<div class=\"description-info\">" . "Description: " . $row["description"] . "</div>";
                        }

                    $output .= "</div>";
           }  
           
      }  
      else  
      {  
         /*$output .= '  
                <tr>  
                     <td colspan="5">No Order Found</td>  
                </tr>  
           ';  
           $output .= ''; */
      }  
      //$output .= '</table>';  


    $isTodayComplete = 0;
    $isSelectedComplete = 0;
    while($row = mysqli_fetch_array($is_complete_result))  
    {
        if ($row["Comp_Workout_Date"] == date("Y-m-d"))
        {
            $isTodayComplete = 1;
        }
        
        if (($selected_date == $row["Comp_Workout_Date"]) && ($row["Comp_Workout_Date"] != date("Y-m-d")))
        {
            $isSelectedComplete = 1;
        }
    }


    if(mysqli_num_rows($is_complete_result) > 0)  
    { 
        if (mysqli_num_rows($result) <= 0) 
        {
            $output .=
            "<div class=\"container\">".
                "<div class=\"row\">".
                    "<div class=\"col-sm-4 offset-sm-4 col-centered offset-xs-5 col-xs-2\">
                        <a class=\"btn btn-default btn-lg btn-block\" id=\"AddExercise\" style=\"background-color:rgb(200,16,46);color:rgb(255,255,255);margin-top:10px;margin-bottom:10px;\">Add Exercise</a>
                    </div>
                </div>".
                "<div class=\"row\">".
                    "<div class=\"col-sm-4 offset-sm-4 col-centered offset-xs-5 col-xs-2\">
                        <form method=\"get\" action=\"./UpdateRewardProgress.php\">
                            <input type = \"hidden\" name = \"id\" value=".$id.">
                            <input type = \"hidden\" name = \"completed_date\" value=".$completed_date.">
                            <input type=\"submit\" value=\"Complete Workout\" class=\"btn btn-default btn-lg btn-block\" id=\"CompleteWorkout\" 
                                style=\"background-color:rgb(200,16,46);color:rgb(255,255,255);margin-top:5px;margin-bottom:5px;\" disabled>
                        </form>               
                    </div>
                </div>
            </div>";
        }
        else if ($isTodayComplete == 0 && $selected_date == date("Y-m-d"))
        {
            $output .=
            "<div class=\"container\">".
                "<div class=\"row\">".
                    "<div class=\"col-sm-4 offset-sm-4 col-centered offset-xs-5 col-xs-2\">
                        <a class=\"btn btn-default btn-lg btn-block\" id=\"AddExercise\" style=\"background-color:rgb(200,16,46);color:rgb(255,255,255);margin-top:10px;margin-bottom:10px;\">Add Exercise</a>
                    </div>
                </div>".
                "<div class=\"row\">".
                    "<div class=\"col-sm-4 offset-sm-4 col-centered offset-xs-5 col-xs-2\">
                        <form method=\"get\" action=\"./UpdateRewardProgress.php\">
                            <input type = \"hidden\" name = \"id\" value=".$id.">
                            <input type = \"hidden\" name = \"completed_date\" value=".$completed_date.">
                            <input type=\"submit\" value=\"Complete Workout\" class=\"btn btn-default btn-lg btn-block\" id=\"CompleteWorkout\" 
                                style=\"background-color:rgb(200,16,46);color:rgb(255,255,255);margin-top:5px;margin-bottom:5px;\" >
                        </form>               
                    </div>
                </div>
            </div>";
        }
        else if ($selected_date > date("Y-m-d"))
        {
            $output .=
            "<div class=\"container\">".
                "<div class=\"row\">".
                    "<div class=\"col-sm-4 offset-sm-4 col-centered offset-xs-5 col-xs-2\">
                        <a class=\"btn btn-default btn-lg btn-block\" id=\"AddExercise\" style=\"background-color:rgb(200,16,46);color:rgb(255,255,255);margin-top:10px;margin-bottom:10px;\">Add Exercise</a>
                    </div>
                </div>".
                "<div class=\"row\">".
                    "<div class=\"col-sm-4 offset-sm-4 col-centered offset-xs-5 col-xs-2\">
                        <form method=\"get\" action=\"./UpdateRewardProgress.php\">
                            <input type = \"hidden\" name = \"id\" value=".$id.">
                            <input type = \"hidden\" name = \"completed_date\" value=".$completed_date.">
                            <input type=\"submit\" value=\"Complete Workout\" class=\"btn btn-default btn-lg btn-block\" id=\"CompleteWorkout\" 
                                style=\"background-color:rgb(200,16,46);color:rgb(255,255,255);margin-top:5px;margin-bottom:5px;\" disabled>
                        </form>               
                    </div>
                </div>
            </div>";
        }
        else 
        {
            $output .=
            "<div class=\"container\">".
                "<div class=\"row\">".
                    "<div class=\"col-sm-4 offset-sm-4 col-centered offset-xs-5 col-xs-2\">
                        <a class=\"btn btn-default btn-lg btn-block\" id=\"AddExercise\" style=\"background-color:rgb(200,16,46);color:rgb(255,255,255);margin-top:10px;margin-bottom:10px;\">Add Exercise</a>
                    </div>
                </div>".
                "<div class=\"row\">".
                    "<div class=\"col-sm-4 offset-sm-4 col-centered offset-xs-5 col-xs-2\">
                        <form method=\"get\" action=\"./UpdateRewardProgress.php\">
                            <input type = \"hidden\" name = \"id\" value=".$id.">
                            <input type = \"hidden\" name = \"completed_date\" value=".$completed_date.">
                            <input type=\"submit\" value=\"Complete Workout\" class=\"btn btn-default btn-lg btn-block\" id=\"CompleteWorkout\" 
                                style=\"background-color:rgb(200,16,46);color:rgb(255,255,255);margin-top:5px;margin-bottom:5px;\" disabled>
                        </form>               
                    </div>
                </div>
            </div>";
        }
    }  
    
     echo $output;
 }  
 ?>