<?php

    $date = $_POST['workout_date'];  //if you used GET in your ajax, then use $_GET here instead


    $query = $this->db->query("select * from Workouts");
    

     $sql = "SELECT * FROM Workouts Where uid='$uid'";
            if($result = mysqli_query($link, $sql)){
                while ($row = mysqli_fetch_array($result, MYSQL_ASSOC)) {
                    echo "<p>" . $row['exercise_name'];
                }   
            }else{
                echo "Something went wrong. Please refresh the page.";
            }
    mysqli_close($link);
    
    

    // foreach ($products as $workouts) {
    //     print $workouts['exercise_name'];
    //
    //     $query = $this->db->query("update oc_order SET date_payed='$date' WHERE  order_id='$orders['exercise_name'];'");
    //
    //     echo "Success";
    // }
?>
